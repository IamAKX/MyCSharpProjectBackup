(C) Powered by Microsoft.
It's comercial licence. Just paid!